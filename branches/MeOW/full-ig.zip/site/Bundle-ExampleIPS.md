# Example SMART IPS - SMART PH4H v0.9.9

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Example SMART IPS**

## Example Bundle: Example SMART IPS



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleIPS",
  "meta" : {
    "profile" : ["http://smart.who.int/ph4h/StructureDefinition/SmartIPS"]
  },
  "language" : "en-GB",
  "identifier" : {
    "system" : "urn:oid:2.16.724.4.8.10.200.10",
    "value" : "175bd032-8b00-4728-b2dc-748bb1501aed"
  },
  "type" : "document",
  "timestamp" : "2024-02-11T11:32:00+01:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:30551ce1-5a28-4356-b684-1e639094ad4d",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "30551ce1-5a28-4356-b684-1e639094ad4d",
      "meta" : {
        "profile" : ["http://smart.who.int/ph4h/StructureDefinition/SmartIPSComposition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><a name=\"Composition_30551ce1-5a28-4356-b684-1e639094ad4d\"> </a><p style=\"margin-bottom: 0px\">Resource &quot;30551ce1-5a28-4356-b684-1e639094ad4d&quot;</p></div><p><b>identifier</b>: id: 3f69e0a5-2177-4540-baab-7a5d0877428f</p><p><b>status</b>: final</p><p><b>type</b>: Patient summary Document <span style=\"background: LightGoldenRodYellow; margin: 4px; border: 1px solid khaki\">(<a href=\"https://loinc.org/\">LOINC</a>#60591-5)</span></p><p><b>date</b>: 2017-12-11 02:30:00+0100</p><p><b>author</b>: Beetje van Hulp, MD</p><p><b>title</b>: Patient Summary as of December 11, 2017 14:30</p><p><b>confidentiality</b>: N</p><blockquote><p><b>attester</b></p><p><b>mode</b>: legal</p><p><b>time</b>: 2017-12-11 02:30:00+0100</p><p><b>party</b>: Beetje van Hulp, MD</p></blockquote><blockquote><p><b>attester</b></p><p><b>mode</b>: legal</p><p><b>time</b>: 2017-12-11 02:30:00+0100</p><p><b>party</b>: Anorg Aniza Tion BV</p></blockquote><p><b>custodian</b>: Anorg Aniza Tion BV</p><h3>RelatesTos</h3><table class=\"grid\"><tr><td>-</td><td><b>Code</b></td><td><b>Target[x]</b></td></tr><tr><td>*</td><td>appends</td><td>id: c2277753-9f90-4a95-8ddb-a0b3f6e7d292</td></tr></table><h3>Events</h3><table class=\"grid\"><tr><td>-</td><td><b>Code</b></td><td><b>Period</b></td></tr><tr><td>*</td><td>care provision <span style=\"background: LightGoldenRodYellow; margin: 4px; border: 1px solid khaki\">(ActClass#PCPR)</span></td><td>?? --&gt; 2017-12-11 02:30:00+0100</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.724.4.8.10.200.10",
        "value" : "3f69e0a5-2177-4540-baab-7a5d0877428f"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5",
          "display" : "Patient summary Document"
        }]
      },
      "subject" : [{
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      }],
      "date" : "2017-12-11T14:30:00+01:00",
      "author" : [{
        "reference" : "urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef"
      }],
      "title" : "Patient Summary as of December 11, 2017 14:30",
      "attester" : [{
        "time" : "2017-12-11T14:30:00+01:00",
        "party" : {
          "reference" : "urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef"
        }
      },
      {
        "time" : "2017-12-11T14:30:00+01:00",
        "party" : {
          "reference" : "urn:uuid:890751f4-2924-4636-bab7-efffc7f3cf15"
        }
      }],
      "custodian" : {
        "reference" : "urn:uuid:890751f4-2924-4636-bab7-efffc7f3cf15"
      },
      "relatesTo" : [null],
      "event" : [{
        "period" : {
          "end" : "2017-12-11T14:30:00+01:00"
        }
      }],
      "section" : [{
        "title" : "Medication",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10160-0",
            "display" : "History of Medication use Narrative"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><thead><tr><th>Medication</th><th>Strength</th><th>Form</th><th>Dosage</th><th>Comment</th></tr></thead><tbody><tr><td>Anastrozole</td><td>1 mg</td><td>tablet</td><td>once daily</td><td>treatment for breast cancer</td></tr><tr><td>Black Cohosh Extract</td><td/><td>pil</td><td/><td>herbal supplement</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:c220e36c-eb67-4fc4-9ba1-2fabc52acec6"
        },
        {
          "reference" : "urn:uuid:47524493-846a-4a26-bae2-4ab03e60f02e"
        }]
      },
      {
        "title" : "Allergies and Intolerances",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48765-2",
            "display" : "Allergies and adverse reactions Document"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Allergy to penicillin, high criticality</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:72884cad-ebe6-4f43-a51a-2f978275f132"
        }]
      },
      {
        "title" : "Active Problems",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4",
            "display" : "Problem list - Reported"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Hot flushes</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:c64139e7-f02d-409c-bf34-75e8bf23bc80"
        }]
      },
      {
        "title" : "Advance Directives",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "42348-3"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Consent MYS for pilgrimage</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:c7781f44-6df8-4a8b-9e06-0b34263a47c7"
        }]
      },
      {
        "title" : "History of Past Illness",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11348-0",
            "display" : "History of Past illness Narrative"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Breast cancer Stage II with no evidence of recurrence following treatment</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:c4597aa2-688a-401b-a658-70acc6de28c6"
        }]
      },
      {
        "title" : "Plan of Treatment",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "18776-5",
            "display" : "Plan of care note"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Continue hormone medication with Anastrozole for total of 5 years and monitor for potential breast cancer recurrence</div>"
        }
      },
      {
        "title" : "Results",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "30954-2",
            "display" : "Relevant diagnostic tests/laboratory data Narrative"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><thead><tr><th colspan=\"3\">Blood typing</th></tr></thead><tbody><tr><td>Blood group</td><td>A+</td><td/></tr><tr><td>C Ab [Presence] in Serum or Plasma</td><td>Positive</td><td/></tr><tr><td>E Ab [Presence] in Serum or Plasma</td><td>Positive</td><td/></tr><tr><td>Little c Ab [Presence] in Serum or Plasma</td><td>Negative</td><td/></tr></tbody></table><table><thead><tr><th colspan=\"3\">Hemoglobin A1c monitoring</th></tr></thead><tbody><tr><td>Hemoglobin A1c/Hemoglobin.total in Blood by HPLC</td><td>7.5 %</td><td/></tr></tbody></table><table><thead><tr><th colspan=\"3\">Bacteriology</th></tr></thead><tbody><tr><td colspan=\"3\">Methicillin resistant Staphylococcus aureus</td></tr><tr><td colspan=\"3\">Healthy carrier of MRSA</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:2639657a-c19a-48e2-82cc-471e13b8ad94"
        },
        {
          "reference" : "urn:uuid:cc354e00-a419-47ea-8b6c-1768b2a01646"
        },
        {
          "reference" : "urn:uuid:26bee0a9-5997-4557-ab9d-c6adbb05b572"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "2b90dd2b-2dab-4c75-9bb9-a355e07401e8",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_2b90dd2b-2dab-4c75-9bb9-a355e07401e8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 2b90dd2b-2dab-4c75-9bb9-a355e07401e8</b></p><a name=\"2b90dd2b-2dab-4c75-9bb9-a355e07401e8\"> </a><a name=\"hc2b90dd2b-2dab-4c75-9bb9-a355e07401e8\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+31788700800\">+31788700800</a></li><li>Laan Van Europa 1600 Dordrecht 3317 DB NL </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: mother\">mother:</td><td colspan=\"3\"><ul><li>Martha Mum </li><li>Promenade des Anglais 111 Lyon 69001 FR </li><li><a href=\"tel:+33-555-20036\">+33-555-20036</a></li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.840.1.113883.2.4.6.3",
        "value" : "574687583"
      }],
      "active" : true,
      "name" : [{
        "family" : "DeLarosa",
        "given" : ["Martha"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+31788700800",
        "use" : "home"
      }],
      "gender" : "female",
      "birthDate" : "1972-05-01",
      "address" : [{
        "line" : ["Laan Van Europa 1600"],
        "city" : "Dordrecht",
        "postalCode" : "3317 DB",
        "country" : "NL"
      }],
      "contact" : [{
        "relationship" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
            "code" : "MTH"
          }]
        }],
        "name" : {
          "family" : "Mum",
          "given" : ["Martha"]
        },
        "telecom" : [{
          "system" : "phone",
          "value" : "+33-555-20036",
          "use" : "home"
        }],
        "address" : {
          "line" : ["Promenade des Anglais 111"],
          "city" : "Lyon",
          "postalCode" : "69001",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "1c616b24-3895-48c4-9a02-9a64110351ef",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_1c616b24-3895-48c4-9a02-9a64110351ef\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 1c616b24-3895-48c4-9a02-9a64110351ef</b></p><a name=\"1c616b24-3895-48c4-9a02-9a64110351ef\"> </a><a name=\"hc1c616b24-3895-48c4-9a02-9a64110351ef\"> </a><p><b>identifier</b>: <code>urn:oid:2.16.528.1.1007.3.1</code>/129854633</p><p><b>active</b>: true</p><p><b>name</b>: Beetje van Hulp </p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0360 MD}\">Doctor of Medicine</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.528.1.1007.3.1",
        "value" : "129854633",
        "assigner" : {
          "display" : "CIBG"
        }
      }],
      "active" : true,
      "name" : [{
        "family" : "van Hulp",
        "given" : ["Beetje"]
      }],
      "qualification" : [{
        "code" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0360",
            "version" : "2.7",
            "code" : "MD",
            "display" : "Doctor of Medicine"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:890751f4-2924-4636-bab7-efffc7f3cf15",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "890751f4-2924-4636-bab7-efffc7f3cf15",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_890751f4-2924-4636-bab7-efffc7f3cf15\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 890751f4-2924-4636-bab7-efffc7f3cf15</b></p><a name=\"890751f4-2924-4636-bab7-efffc7f3cf15\"> </a><a name=\"hc890751f4-2924-4636-bab7-efffc7f3cf15\"> </a><p><b>identifier</b>: <code>urn:oid:2.16.528.1.1007.3.3</code>/564738757</p><p><b>active</b>: true</p><p><b>name</b>: Anorg Aniza Tion BV / The best custodian ever</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Telecom</b></td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"tel:+31-51-34343400\">+31-51-34343400</a></td><td>Houttuinen 27 Dordrecht 3311 CE NL (work)</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.528.1.1007.3.3",
        "value" : "564738757"
      }],
      "active" : true,
      "name" : "Anorg Aniza Tion BV / The best custodian ever",
      "contact" : [{
        "telecom" : [{
          "system" : "phone",
          "value" : "+31-51-34343400",
          "use" : "work"
        }],
        "address" : {
          "use" : "work",
          "line" : ["Houttuinen 27"],
          "city" : "Dordrecht",
          "postalCode" : "3311 CE",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c64139e7-f02d-409c-bf34-75e8bf23bc80",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "c64139e7-f02d-409c-bf34-75e8bf23bc80",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_c64139e7-f02d-409c-bf34-75e8bf23bc80\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition c64139e7-f02d-409c-bf34-75e8bf23bc80</b></p><a name=\"c64139e7-f02d-409c-bf34-75e8bf23bc80\"> </a><a name=\"hcc64139e7-f02d-409c-bf34-75e8bf23bc80\"> </a><p><b>identifier</b>: <code>urn:oid:1.2.3.999</code>/c87bf51c-e53c-4bfe-b8b7-aa62bdd93002</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 75326-9}\">Problem</span></p><p><b>severity</b>: <span title=\"Codes:{http://loinc.org LA6751-7}\">Moderate</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 198436008}, {http://hl7.org/fhir/sid/icd-10 N95.1}\">Menopausal flushing (finding)</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>onset</b>: 2015</p><p><b>recordedDate</b>: 2016-10</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.3.999",
        "value" : "c87bf51c-e53c-4bfe-b8b7-aa62bdd93002"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75326-9",
          "display" : "Problem"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6751-7",
          "display" : "Moderate"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "198436008",
          "display" : "Menopausal flushing (finding)",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "nl-NL"
              },
              {
                "url" : "content",
                "valueString" : "opvliegers"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        },
        {
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "N95.1",
          "display" : "Menopausal and female climacteric states"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "onsetDateTime" : "2015",
      "recordedDate" : "2016-10"
    }
  },
  {
    "fullUrl" : "urn:uuid:c220e36c-eb67-4fc4-9ba1-2fabc52acec6",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "c220e36c-eb67-4fc4-9ba1-2fabc52acec6",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_c220e36c-eb67-4fc4-9ba1-2fabc52acec6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement c220e36c-eb67-4fc4-9ba1-2fabc52acec6</b></p><a name=\"c220e36c-eb67-4fc4-9ba1-2fabc52acec6\"> </a><a name=\"hcc220e36c-eb67-4fc4-9ba1-2fabc52acec6\"> </a><p><b>identifier</b>: <code>urn:oid:1.2.3.999</code>/b75f92cb-61d4-469a-9387-df5ef70d25f0</p><p><b>status</b>: Recorded</p><h3>Medications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-ExampleIPS.html#urn-uuid-976d0804-cae0-45ae-afe3-a19f3ceba6bc\">Medication Product containing anastrozole (medicinal product)</a></td></tr></table><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-03 --&gt; (ongoing)</p><blockquote><p><b>dosage</b></p><p><b>timing</b>: Count 1  times, Once</p><p><b>route</b>: <span title=\"Codes:{http://standardterms.edqm.eu 20053000}\">Oral use</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/dose-rate-type ordered}\">Ordered</span></td><td>1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.3.999",
        "value" : "b75f92cb-61d4-469a-9387-df5ef70d25f0"
      }],
      "status" : "recorded",
      "medication" : {
        "reference" : {
          "reference" : "urn:uuid:976d0804-cae0-45ae-afe3-a19f3ceba6bc"
        }
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectivePeriod" : {
        "start" : "2015-03"
      },
      "dosage" : [{
        "timing" : {
          "repeat" : {
            "count" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20053000",
            "display" : "Oral use"
          }]
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/dose-rate-type",
              "code" : "ordered",
              "display" : "Ordered"
            }]
          },
          "doseQuantity" : {
            "value" : 1,
            "unit" : "tablet",
            "system" : "http://unitsofmeasure.org",
            "code" : "1"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:47524493-846a-4a26-bae2-4ab03e60f02e",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "47524493-846a-4a26-bae2-4ab03e60f02e",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_47524493-846a-4a26-bae2-4ab03e60f02e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement 47524493-846a-4a26-bae2-4ab03e60f02e</b></p><a name=\"47524493-846a-4a26-bae2-4ab03e60f02e\"> </a><a name=\"hc47524493-846a-4a26-bae2-4ab03e60f02e\"> </a><p><b>identifier</b>: <code>urn:oid:1.2.3.999</code>/9e312d6b-c6b6-439a-a730-6efaa5dcf8bc</p><p><b>status</b>: Recorded</p><h3>Medications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-ExampleIPS.html#urn-uuid-8adc0999-9468-4ac9-9557-680fa133d626\">Medication Cimicifuga racemosa extract (substance)</a></td></tr></table><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2016-01 --&gt; (ongoing)</p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Route</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://standardterms.edqm.eu 20053000}\">Oral use</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.3.999",
        "value" : "9e312d6b-c6b6-439a-a730-6efaa5dcf8bc"
      }],
      "status" : "recorded",
      "medication" : {
        "reference" : {
          "reference" : "urn:uuid:8adc0999-9468-4ac9-9557-680fa133d626"
        }
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectivePeriod" : {
        "start" : "2016-01"
      },
      "dosage" : [{
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20053000",
            "display" : "Oral use"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:976d0804-cae0-45ae-afe3-a19f3ceba6bc",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "976d0804-cae0-45ae-afe3-a19f3ceba6bc",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_976d0804-cae0-45ae-afe3-a19f3ceba6bc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication 976d0804-cae0-45ae-afe3-a19f3ceba6bc</b></p><a name=\"976d0804-cae0-45ae-afe3-a19f3ceba6bc\"> </a><a name=\"hc976d0804-cae0-45ae-afe3-a19f3ceba6bc\"> </a><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 108774000}, {urn:oid:2.16.840.1.113883.2.4.4.1 99872}, {urn:oid:2.16.840.1.113883.2.4.4.7 2076667}, {http://www.whocc.no/atc L02BG03}\">Product containing anastrozole (medicinal product)</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108774000",
          "display" : "Product containing anastrozole (medicinal product)"
        },
        {
          "system" : "urn:oid:2.16.840.1.113883.2.4.4.1",
          "code" : "99872",
          "display" : "ANASTROZOL 1MG TABLET"
        },
        {
          "system" : "urn:oid:2.16.840.1.113883.2.4.4.7",
          "code" : "2076667",
          "display" : "ANASTROZOL CF TABLET FILMOMHULD 1MG"
        },
        {
          "system" : "http://www.whocc.no/atc",
          "code" : "L02BG03",
          "display" : "anastrozole"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:8adc0999-9468-4ac9-9557-680fa133d626",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "8adc0999-9468-4ac9-9557-680fa133d626",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_8adc0999-9468-4ac9-9557-680fa133d626\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication 8adc0999-9468-4ac9-9557-680fa133d626</b></p><a name=\"8adc0999-9468-4ac9-9557-680fa133d626\"> </a><a name=\"hc8adc0999-9468-4ac9-9557-680fa133d626\"> </a><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 412588001}, {http://www.whocc.no/atc G02CX04}\">Black Cohosh Extract herbal supplement</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "412588001",
          "display" : "Cimicifuga racemosa extract (substance)",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "nl-NL"
              },
              {
                "url" : "content",
                "valueString" : "Zwarte Cohosh Extract"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        },
        {
          "system" : "http://www.whocc.no/atc",
          "code" : "G02CX04",
          "display" : "Cimicifugae rhizoma"
        }],
        "text" : "Black Cohosh Extract herbal supplement"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:72884cad-ebe6-4f43-a51a-2f978275f132",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "72884cad-ebe6-4f43-a51a-2f978275f132",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_72884cad-ebe6-4f43-a51a-2f978275f132\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AllergyIntolerance 72884cad-ebe6-4f43-a51a-2f978275f132</b></p><a name=\"72884cad-ebe6-4f43-a51a-2f978275f132\"> </a><a name=\"hc72884cad-ebe6-4f43-a51a-2f978275f132\"> </a><p><b>Abatement</b>: 2010</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>type</b>: <span title=\"Codes:\">allergy</span></p><p><b>category</b>: Medication</p><p><b>criticality</b>: High Risk</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 373270004}\">Substance with penicillin structure and antibacterial mechanism of action (substance)</span></p><p><b>patient</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>onset</b>: Absent because : unknown</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/allergyintolerance-abatement",
        "valueDateTime" : "2010"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed"
        }]
      },
      "type" : {
        "coding" : [{
          "code" : "allergy"
        }]
      },
      "category" : ["medication"],
      "criticality" : "high",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "373270004",
          "display" : "Substance with penicillin structure and antibacterial mechanism of action (substance)"
        }]
      },
      "patient" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "_onsetDateTime" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
          "valueCode" : "unknown"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:c4597aa2-688a-401b-a658-70acc6de28c6",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "c4597aa2-688a-401b-a658-70acc6de28c6",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_c4597aa2-688a-401b-a658-70acc6de28c6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition c4597aa2-688a-401b-a658-70acc6de28c6</b></p><a name=\"c4597aa2-688a-401b-a658-70acc6de28c6\"> </a><a name=\"hcc4597aa2-688a-401b-a658-70acc6de28c6\"> </a><p><b>identifier</b>: <code>urn:oid:1.2.3.999</code>/66d4a8c7-9081-43e0-a63f-489c2ae6edd6</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical remission}\">Remission</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 75326-9}\">Problem</span></p><p><b>severity</b>: <span title=\"Codes:{http://loinc.org LA6750-9}\">Severe</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 254837009}, {http://terminology.hl7.org/CodeSystem/icd-o-3 8500/3}\">Malignant tumor of breast</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>onset</b>: 2015-01</p><p><b>abatement</b>: 2015-03</p></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.2.3.999",
        "value" : "66d4a8c7-9081-43e0-a63f-489c2ae6edd6"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "remission"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75326-9",
          "display" : "Problem"
        }]
      }],
      "severity" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6750-9",
          "display" : "Severe"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "254837009",
          "display" : "Malignant tumor of breast",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "nl-NL"
              },
              {
                "url" : "content",
                "valueString" : "Borstkanker stadium II zonder aanwijzingen van recidieven na behandeling"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        },
        {
          "system" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
          "code" : "8500/3",
          "display" : "Infiltrating duct carcinoma, NOS"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "onsetDateTime" : "2015-01",
      "abatementDateTime" : "2015-03"
    }
  },
  {
    "fullUrl" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7</b></p><a name=\"45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\"> </a><a name=\"hc45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\"> </a><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type other}\">Other</span></p><p><b>name</b>: Laboratoire de charme</p></div>"
      },
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "other"
        }]
      }],
      "name" : "Laboratoire de charme"
    }
  },
  {
    "fullUrl" : "urn:uuid:aa11a2be-3e36-4be7-b58a-6fc3dace2741",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "aa11a2be-3e36-4be7-b58a-6fc3dace2741",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_aa11a2be-3e36-4be7-b58a-6fc3dace2741\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation aa11a2be-3e36-4be7-b58a-6fc3dace2741</b></p><a name=\"aa11a2be-3e36-4be7-b58a-6fc3dace2741\"> </a><a name=\"hcaa11a2be-3e36-4be7-b58a-6fc3dace2741\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 882-1}\">ABO and Rh group [Type] in Blood</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-10-10 09:15:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 278149003}\">Blood group A Rh(D) positive</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "882-1",
          "display" : "ABO and Rh group [Type] in Blood"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2015-10-10T09:15:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "278149003",
          "display" : "Blood group A Rh(D) positive"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:6e39ccf3-f997-4a2b-8f28-b4b71c778c70",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "6e39ccf3-f997-4a2b-8f28-b4b71c778c70",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_6e39ccf3-f997-4a2b-8f28-b4b71c778c70\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 6e39ccf3-f997-4a2b-8f28-b4b71c778c70</b></p><a name=\"6e39ccf3-f997-4a2b-8f28-b4b71c778c70\"> </a><a name=\"hc6e39ccf3-f997-4a2b-8f28-b4b71c778c70\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 945-6}\">C Ab [Presence] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-10-10 09:35:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "945-6",
          "display" : "C Ab [Presence] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2015-10-10T09:35:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:b4916505-a06b-460c-9be8-011609282457",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "b4916505-a06b-460c-9be8-011609282457",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_b4916505-a06b-460c-9be8-011609282457\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation b4916505-a06b-460c-9be8-011609282457</b></p><a name=\"b4916505-a06b-460c-9be8-011609282457\"> </a><a name=\"hcb4916505-a06b-460c-9be8-011609282457\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1018-1}\">E Ab [Presence] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-10-10 09:35:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "1018-1",
          "display" : "E Ab [Presence] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2015-10-10T09:35:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4</b></p><a name=\"a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4\"> </a><a name=\"hca6a5a1d5-c896-4c7e-b922-888fcc7e6ae4\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1156-9}\">little c Ab [Presence] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-10-10 09:35:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 260385009}\">Negative</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "1156-9",
          "display" : "little c Ab [Presence] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2015-10-10T09:35:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260385009",
          "display" : "Negative"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:2639657a-c19a-48e2-82cc-471e13b8ad94",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2639657a-c19a-48e2-82cc-471e13b8ad94",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_2639657a-c19a-48e2-82cc-471e13b8ad94\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 2639657a-c19a-48e2-82cc-471e13b8ad94</b></p><a name=\"2639657a-c19a-48e2-82cc-471e13b8ad94\"> </a><a name=\"hc2639657a-c19a-48e2-82cc-471e13b8ad94\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:\">Blood typing</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2015-10-10</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>hasMember</b>: </p><ul><li><a href=\"Bundle-ExampleIPS.html#urn-uuid-aa11a2be-3e36-4be7-b58a-6fc3dace2741\">Observation ABO and Rh group [Type] in Blood</a></li><li><a href=\"Bundle-ExampleIPS.html#urn-uuid-6e39ccf3-f997-4a2b-8f28-b4b71c778c70\">Observation C Ab [Presence] in Serum or Plasma</a></li><li><a href=\"Bundle-ExampleIPS.html#urn-uuid-b4916505-a06b-460c-9be8-011609282457\">Observation E Ab [Presence] in Serum or Plasma</a></li><li><a href=\"Bundle-ExampleIPS.html#urn-uuid-a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4\">Observation little c Ab [Presence] in Serum or Plasma</a></li></ul></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "text" : "Blood typing"
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2015-10-10",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "hasMember" : [{
        "reference" : "urn:uuid:aa11a2be-3e36-4be7-b58a-6fc3dace2741"
      },
      {
        "reference" : "urn:uuid:6e39ccf3-f997-4a2b-8f28-b4b71c778c70"
      },
      {
        "reference" : "urn:uuid:b4916505-a06b-460c-9be8-011609282457"
      },
      {
        "reference" : "urn:uuid:a6a5a1d5-c896-4c7e-b922-888fcc7e6ae4"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:cc354e00-a419-47ea-8b6c-1768b2a01646",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "cc354e00-a419-47ea-8b6c-1768b2a01646",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_cc354e00-a419-47ea-8b6c-1768b2a01646\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation cc354e00-a419-47ea-8b6c-1768b2a01646</b></p><a name=\"cc354e00-a419-47ea-8b6c-1768b2a01646\"> </a><a name=\"hccc354e00-a419-47ea-8b6c-1768b2a01646\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 17856-6}\">Hemoglobin A1c/Hemoglobin.total in Blood by HPLC</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2017-11-10 08:20:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: 7.5 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>note</b>: </p><blockquote><div><p>Above stated goal of 7.0 %</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "17856-6",
          "display" : "Hemoglobin A1c/Hemoglobin.total in Blood by HPLC"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2017-11-10T08:20:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueQuantity" : {
        "value" : 7.5,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "note" : [{
        "text" : "Above stated goal of 7.0 %"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:26bee0a9-5997-4557-ab9d-c6adbb05b572",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "26bee0a9-5997-4557-ab9d-c6adbb05b572",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_26bee0a9-5997-4557-ab9d-c6adbb05b572\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 26bee0a9-5997-4557-ab9d-c6adbb05b572</b></p><a name=\"26bee0a9-5997-4557-ab9d-c6adbb05b572\"> </a><a name=\"hc26bee0a9-5997-4557-ab9d-c6adbb05b572\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 42803-7}\">Bacteria identified in Isolate</span></p><p><b>subject</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-2b90dd2b-2dab-4c75-9bb9-a355e07401e8\">Martha DeLarosa  Female, DoB: 1972-05-01 ( urn:oid:2.16.840.1.113883.2.4.6.3#574687583)</a></p><p><b>effective</b>: 2017-12-10 08:20:00+0100</p><p><b>performer</b>: <a href=\"Bundle-ExampleIPS.html#urn-uuid-45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7\">Organization Laboratoire de charme</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 115329001}\">Methicillin resistant Staphylococcus aureus</span></p><p><b>note</b>: </p><blockquote><div><p>Healthy carrier of MRSA</p>\n</div></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "42803-7",
          "display" : "Bacteria identified in Isolate"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:2b90dd2b-2dab-4c75-9bb9-a355e07401e8"
      },
      "effectiveDateTime" : "2017-12-10T08:20:00+01:00",
      "performer" : [{
        "reference" : "urn:uuid:45a5c5b1-4ec1-4d60-b4b2-ff5a84a41fd7"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "115329001",
          "display" : "Methicillin resistant Staphylococcus aureus"
        }]
      },
      "note" : [{
        "text" : "Healthy carrier of MRSA"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c7781f44-6df8-4a8b-9e06-0b34263a47c7",
    "resource" : {
      "resourceType" : "Consent",
      "id" : "c7781f44-6df8-4a8b-9e06-0b34263a47c7",
      "meta" : {
        "profile" : ["http://smart.who.int/ph4h/StructureDefinition/SmartConsent"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_c7781f44-6df8-4a8b-9e06-0b34263a47c7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent c7781f44-6df8-4a8b-9e06-0b34263a47c7</b></p><a name=\"c7781f44-6df8-4a8b-9e06-0b34263a47c7\"> </a><a name=\"hcc7781f44-6df8-4a8b-9e06-0b34263a47c7\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-SmartConsent.html\">SMART Consent</a></p></div><h2>Participants</h2><table class=\"grid\"><tr><td><b>Role</b></td><td><b>Details</b></td></tr></table><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: 1px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top;\"><tr style=\"border: 2px #F0F0F0 solid; font-size: 11px; font-family: verdana; vertical-align: top\"><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R5/formats.html#table\" title=\"Applicable Rule\">Rule</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R5/formats.html#table\" title=\"Applicable Period\">Time Period</a></th><th style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; padding-top: 3px; padding-bottom: 3px\" class=\"hierarchy\"><a href=\"https://hl7.org/fhir/R5/formats.html#table\" title=\"Applicable Data\">What</a><span style=\"float: right\"><a href=\"https://hl7.org/fhir/R5/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/></a></span></th></tr><tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: white\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck1.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon-qi-hidden.png\" alt=\".\" style=\"background-color: white; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> deny</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: white; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"></td></tr>\r\n<tr style=\"border: 1px #F0F0F0 solid; padding:0px; vertical-align: top; background-color: #F7F7F7\"><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px; white-space: nowrap; background-image: url(tbl_bck00.png)\" class=\"hierarchy\"><img src=\"tbl_spacer.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"tbl_vjoin_end.png\" alt=\".\" style=\"background-color: inherit\" class=\"hierarchy\"/><img src=\"icon_extension.png\" alt=\".\" style=\"background-color: #F7F7F7; background-color: inherit\" title=\"Consent Provision\" class=\"hierarchy\"/> permit</td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Period: 1964-01-01 --&gt; 2016-01-01</li></ul></td><td style=\"vertical-align: top; text-align : var(--ig-left,left); background-color: #F7F7F7; border: 1px #F0F0F0 solid; padding:0px 4px 0px 4px\" class=\"hierarchy\"><ul><li>Purpose: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html#v3-ActReason-COC\">ActReason: COC</a> (coordination of care)</li></ul></td></tr>\r\n<tr><td colspan=\"3\" class=\"hierarchy\"><br/><a href=\"https://hl7.org/fhir/R5/formats.html#table\" title=\"Legend for this format\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3goXBCwdPqAP0wAAAldJREFUOMuNk0tIlFEYhp9z/vE2jHkhxXA0zJCMitrUQlq4lnSltEqCFhFG2MJFhIvIFpkEWaTQqjaWZRkp0g26URZkTpbaaOJkDqk10szoODP//7XIMUe0elcfnPd9zsfLOYplGrpRwZaqTtw3K7PtGem7Q6FoidbGgqHVy/HRb669R+56zx7eRV1L31JGxYbBtjKK93cxeqfyQHbehkZbUkK20goELEuIzEd+dHS+qz/Y8PTSif0FnGkbiwcAjHaU1+QWOptFiyCLp/LnKptpqIuXHx6rbR26kJcBX3yLgBfnd7CxwJmflpP2wUg0HIAoUUpZBmKzELGWcN8nAr6Gpu7tLU/CkwAaoKTWRSQyt89Q8w6J+oVQkKnBoblH7V0PPvUOvDYXfopE/SJmALsxnVm6LbkotrUtNowMeIrVrBcBpaMmdS0j9df7abpSuy7HWehwJdt1lhVwi/J58U5beXGAF6c3UXLycw1wdFklArBn87xdh0ZsZtArghBdAA3+OEDVubG4UEzP6x1FOWneHh2VDAHBAt80IbdXDcesNoCvs3E5AFyNSU5nbrDPZpcUEQQTFZiEVx+51fxMhhyJEAgvlriadIJZZksRuwBYMOPBbO3hePVVqgEJhFeUuFLhIPkRP6BQLIBrmMenujm/3g4zc398awIe90Zb5A1vREALqneMcYgP/xVQWlG+Ncu5vgwwlaUNx+3799rfe96u9K0JSDXcOzOTJg4B6IgmXfsygc7/Bvg9g9E58/cDVmGIBOP/zT8Bz1zqWqpbXIsd0O9hajXfL6u4BaOS6SeWAAAAAElFTkSuQmCC\" alt=\"doco\" style=\"background-color: inherit\"/> Documentation for this format</a></td></tr></table></div>"
      },
      "status" : "active",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentcategorycodes",
          "code" : "acd"
        }]
      }],
      "sourceReference" : [{
        "reference" : "DocumentReference/ex-documentreference"
      }],
      "provision" : [{
        "period" : {
          "start" : "1964-01-01",
          "end" : "2016-01-01"
        },
        "purpose" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "COC"
        }]
      }]
    }
  }]
}

```
